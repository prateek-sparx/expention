CalendarPlugin
==============

Sample PhoneGap plugin to access and add entries to the native calendar on Android. 

Install
========
Assuming the PhoneGap CLI is installed, from the command line run:

phonegap local plugin add https://github.com/hollyschinsky/CalendarPlugin
